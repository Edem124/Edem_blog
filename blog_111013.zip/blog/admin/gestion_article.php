<?php require('database.php');
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
include'../include/navadmin.php';
$articles= $bdd->query('SELECT * FROM articles ORDER BY id DESC')



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/form.css">
    <title>Gestion d'article</title>
</head>
<body>

	
	<div class="">
		<table>
  <caption><strong>Gestion des articles</strong></caption>
  <thead>
    <tr>
     
      <th scope="col">Num</th>
      <th scope="col">Titre</th>
      <th scope="col">Image</th>
      <th scope="col">Date de publication</th>
      <th scope="col">Statue</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  	<?php 
   while($a = $articles->fetch()){
   ?>
               
     
    <tr>
      <td ><?= $a['id'] ?></td>
      <td ><?= $a['titre'] ?></td>
      <td ><?= $a['image'] ?></td>
      <td ><?= $a['date_time_publication'] ?></td>
      <td ><?= $a['statue'] ?></td>
      
      <td > 
      	
      </td>
      
    </tr>
     <?php
      }
      ?>
   
  </tbody>
</table>
<style type="text/css">
	
table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}

table caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;

  }
  
  table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

</style>
			
	</div>





</body>
</html>