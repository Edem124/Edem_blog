<?php require('database.php');
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
include'../include/navadmin.php';
if(isset($_POST['validate'])){
    if(!empty($_POST['titre']) AND !empty($_POST['contenu'])){
        $titre = htmlspecialchars($_POST['titre']);
		$contenu = htmlspecialchars($_POST['contenu']);
        


        $insertArticleOnWebsite = $bdd->prepare('INSERT INTO articles(titre, contenu, date_time_publication)
            VALUES (?, ?, NOW())');
        $insertArticleOnWebsite->execute(array($titre, $contenu));
        $success = 'Votre article a été posté';



    }else{
        $error = 'Veuillez remplir tout les champs';
    }
}





?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/form.css">
    <title>Rédaction d'article</title>
</head>
<body>
     <form action="" id="" method="POST">
        <h1>Ajouter un article</h1><br>
       
      <label for="titre" id="">Titre:</label>
      <input type="text" name="titre" id="nom" placeholder="Votre titre" ><br>

      <label for="contenu" id="">Contenu:</label>
      <textarea id="prenom" name ="contenu"  placeholder="Votre Contenu" ></textarea><br>
      <br>
      <br>

      <button id="submit" name="validate" class="btn-submit" type="submit">Envoyer l'article</button>
      
      
    </form>
    <?php 
        if (isset($error)) {            
         ?>
         <div style="color: white;, text-align: center; background-color: red ; padding: 15px;"> <?=$error ?></div>

         <?php 
        }
          ?>

          <?php 
        if (isset($success)) {          
         ?>
         <div style="color: white;, text-align: center; background-color: green ; padding: 15px;"> <?=$success ?></div>

         <?php 
        }
          ?>
</body>
</html>