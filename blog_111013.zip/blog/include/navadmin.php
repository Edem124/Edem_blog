
    <header class="header">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="logo">
                   <a href="#"><img src="../assets/images/logo.png" width="150"></a>
                </div>
                <button type="button" class="nav-toggler">
                   <span></span>
                </button>
                <nav class="nav">
                   <ul>
                      <li><a href="ajouter_article.php" class="active">Ajouter article</a></li>
                      <li><a href="gestion_article.php" >Gestion article</a></li>
                      <li><a href="gestion_comment.php">Commentaire</a></li>
                      <li><a href="gestion_email.php">Mail</a></li>
                     
                   </ul>
                </nav>
            </div>
        </div>
     </header>