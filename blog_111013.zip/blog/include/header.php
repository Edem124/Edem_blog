<!--
    - #HEADER
  -->

  <header>

    <div class="container">

      <nav class="navbar">

        <a href="#">
          <img src="./assets/images/logo.png" alt="Devblog's logo" width="150" class="logo-light">
          <img src="./assets/images/logo.png" alt="Devblog's logo" width="150" class="logo-dark">
        </a>

        <div class="btn-group">

          <button class="theme-btn theme-btn-mobile light">
            <ion-icon name="moon" class="moon"></ion-icon>
            <ion-icon name="sunny" class="sun"></ion-icon>
          </button>

          <button class="nav-menu-btn">
            <ion-icon name="menu-outline"></ion-icon>
          </button>

        </div>

        <div class="flex-wrapper">

          <ul class="desktop-nav">

            <li>
              <a href="#" class="nav-link">Home</a>
            </li>

            <li>
              <a href="#" class="nav-link"> Apropos</a>
            </li>

            <li>
              <a href="#" class="nav-link"> Me contacter</a>
            </li>
            <li>
                <a href="admin/accueil.php" class="nav-link">Admin</a>
            </li>
          </ul>

          <button class="theme-btn theme-btn-desktop light">
            <ion-icon name="moon" class="moon"></ion-icon>
            <ion-icon name="sunny" class="sun"></ion-icon>
          </button>

        </div>

        <div class="mobile-nav">

          <button class="nav-close-btn">
            <ion-icon name="close-outline"></ion-icon>
          </button>

          <div class="wrapper">

            <p class="h3 nav-title"> Menu</p>

            <ul>
              <li class="nav-item">
                <a href="#" class="nav-link">Home</a>
              </li>

              <li class="nav-item">
                <a href="#" class="nav-link">Apropos</a>
              </li>

              <li class="nav-item">
                <a href="#" class="nav-link">Me contacter</a>
              </li>
             
            </ul>

          </div>

          <div>

            <p class="h3 nav-title">Domaines</p>

            <ul>
              <li class="nav-item">
                <a href="#" class="nav-link">Programmation</a>
              </li>

              <li class="nav-item">
                <a href="#" class="nav-link">Domotique</a>
              </li>

              <li class="nav-item">
                <a href="#" class="nav-link">Electronique</a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">Robotique</a>
              </li>
            </ul>

          </div>

        </div>

      </nav>

    </div>

  </header>



