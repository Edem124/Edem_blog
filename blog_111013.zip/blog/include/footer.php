 <!--
    - #FOOTER
  -->

  <footer>

    <div class="container">

      <div class="wrapper">

        <a href="#" class="footer-logo">
          <img src="../assets/images/logo.png" alt="DevBlog's Logo" width="150" class="logo-light">
          <img src="../assets/images/logo.png" alt="DevBlog's Logo" width="150" class="logo-dark">
        </a>

        <p class="footer-text">
          Apprener plus sur le développement 
        </p>

      </div>

      <div class="wrapper">

        <p class="footer-title">Quick Links</p>

        <ul>

          <li>
            <a href="#" class="footer-link">Avertisser nous </a>
          </li>

          <li>
            <a href="#" class="footer-link">Apropos</a>
          </li>

          <li>
            <a href="#" class="footer-link">Nous contacter</a>
          </li>

        </ul>

      </div>

      <div class="wrapper">

        <p class="footer-title">Legal Stuff</p>

        <ul>

          <li>
            <a href="#" class="footer-link">Privacy Notice</a>
          </li>

          <li>
            <a href="#" class="footer-link">Cookie Policy</a>
          </li>

          <li>
            <a href="#" class="footer-link">Terms Of Use</a>
          </li>

        </ul>

      </div>

    </div>

    <p class="copyright">
      &copy; Copyright 2022 Edem MADETIN
    </p>

  </footer>



