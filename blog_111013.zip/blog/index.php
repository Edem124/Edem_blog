<?php require('./admin/database.php');
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if( isset($_GET['id'])AND !empty($_GET['id'])){
  $idofA= htmlspecialchars($_GET['id']);

  $article = $bdd->prepare('SELECT * FROM articles WHERE id=?');
  $article->execute(array($idofA));

if($article->rowCount() == 1){
    $article = $article->fetch();
    $titre = $article['titre'];
    $contenu = $article['contenu'];
} else{
  die('non retrouvé');
}
}else{
  die('erreur');
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'include/head.php'; ?>
<body class="light-theme">
<?php include 'include/header.php'; ?>
  

  <main>

    <!--
      - #MOI
    -->

    <div class="hero">

      <div class="container">

        <div class="left">

          <h1 class="h1">
            Bienvenue!!! <b>Edem&nbsp;MADETIN</b>
            <br>Web Developer
          </h1>

          <p class="h3">
          Etudiant <abbr title="Accessibility">à</abbr>
            ESGIS Bénin
          </p>

          <div class="btn-group">
            <a href="#" class="btn btn-primary">Me contacter</a>
            <a href="#" class="btn btn-secondary">Apropos</a>
          </div>

        </div>

        <div class="right">

          <div class="pattern-bg"></div>
          <div class="img-box">
            <img src="./assets/images/hero.jpg" alt="Edem MADETIN" class="hero-img">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
          </div>

        </div>

      </div>

    </div>





    <div class="main">

      <div class="container">

        <!--
          - BLOG SECTION
        -->

        <div class="blog">

          <h2 class="h2">Anciens Posts</h2>

          <div class="blog-card-group">

            <div class="blog-card">

              <div class="blog-card-banner">
                <img src="./assets/images/blog-1.png" alt=""
                  width="250" class="blog-banner-img">
              </div>

              <div class="blog-content-wrapper">

                <button class="blog-topic text-tiny">Programation</button>

                <h3>
                  <a href="#" class="h3">
                   <?= $titre ?>
                  </a>
                </h3>

                <p class="blog-text">
                 <?= $contenu ?>
                </p>

                <div class="wrapper-flex">

                  <div class="profile-wrapper">
                    <img src="./assets/images/hero.jpg" alt="Julia Walker" width="50">
                  </div>

                  <div class="wrapper">
                    <a href="#" class="h4">Edem MADETIN</a>

                    <p class="text-sm">
                      <time datetime="2022-01-17">Jan 17, 2022</time>
                      <span class="separator"></span>
                      <ion-icon name="time-outline"></ion-icon>
                      <time datetime="PT3M">3 min</time>
                    </p>
                  </div>

                </div>

              </div>

            </div>
            <div class="blog-card">

              <div class="blog-card-banner">
                <img src="./assets/images/blog-2.jpg"
                  alt="Building a Restful CRUD API with Node JS, Express, and MongoDB" width="250"
                  class="blog-banner-img">
              </div>

              <div class="blog-content-wrapper">

                <button class="blog-topic text-tiny">Domotique</button>

                <h3><a href="" class="h3">Lorem ipsum dolor sit amet consectetur adipisicing elit.</a></h3>

                <p class="blog-text">
                 Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                 Doloribus temporibus aut omnis dicta voluptate sapiente accusantium nam consequatur animi, cumque enim rem deleniti incidunt soluta minima sit debitis cum aliquid!
                </p>

                <div class="wrapper-flex">

                  <div class="profile-wrapper">
                    <img src="./assets/images/hero.jpg" alt="Edem MADETIN" width="50">
                  </div>

                  <div class="wrapper">
                    <a href="#" class="h4">Edem MADETIN</a>

                    <p class="text-sm">
                      <time datetime="2021-10-15">Oct 15, 2021</time>
                      <span class="separator"></span>
                      <ion-icon name="time-outline"></ion-icon>
                      <time datetime="PT5M">5 min</time>
                    </p>
                  </div>

                </div>

              </div>

            </div>


            <div class="blog-card">

              <div class="blog-card-banner">
                <img src="./assets/images/blog-3.png"
                  alt="Building a Restful CRUD API with Node JS, Express, and MongoDB" width="250"
                  class="blog-banner-img">
              </div>

              <div class="blog-content-wrapper">

                <button class="blog-topic text-tiny">Electronique</button>

                <h3><a href="" class="h3">Lorem ipsum dolor sit amet consectetur adipisicing elit.</a></h3>

                <p class="blog-text">
                 Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                 Doloribus temporibus aut omnis dicta voluptate sapiente accusantium nam consequatur animi, cumque enim rem deleniti incidunt soluta minima sit debitis cum aliquid!
                </p>

                <div class="wrapper-flex">

                  <div class="profile-wrapper">
                    <img src="./assets/images/hero.jpg" alt="Edem MADETIN" width="50">
                  </div>

                  <div class="wrapper">
                    <a href="#" class="h4">Edem MADETIN</a>

                    <p class="text-sm">
                      <time datetime="2021-10-15">Oct 15, 2021</time>
                      <span class="separator"></span>
                      <ion-icon name="time-outline"></ion-icon>
                      <time datetime="PT5M">5 min</time>
                    </p>
                  </div>

                </div>

              </div>

            </div>


           

            <div class="blog-card">

              <div class="blog-card-banner">
                <img src="./assets/images/blog-4.png"
                  alt="Building a Restful CRUD API with Node JS, Express, and MongoDB" width="250"
                  class="blog-banner-img">
              </div>

              <div class="blog-content-wrapper">

                <button class="blog-topic text-tiny">Robotique</button>

                <h3><a href="" class="h3">Lorem ipsum dolor sit amet consectetur adipisicing elit.</a></h3>

                <p class="blog-text">
                 Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                 Doloribus temporibus aut omnis dicta voluptate sapiente accusantium nam consequatur animi, cumque enim rem deleniti incidunt soluta minima sit debitis cum aliquid!
                </p>

                <div class="wrapper-flex">

                  <div class="profile-wrapper">
                    <img src="./assets/images/hero.jpg" alt="Edem MADETIN" width="50">
                  </div>

                  <div class="wrapper">
                    <a href="#" class="h4">Edem MADETIN</a>

                    <p class="text-sm">
                      <time datetime="2021-10-15">Oct 15, 2021</time>
                      <span class="separator"></span>
                      <ion-icon name="time-outline"></ion-icon>
                      <time datetime="PT5M">5 min</time>
                    </p>
                  </div>

                </div>

              </div>

            </div>

          </div>

          <button class="btn load-more">Lire plus</button>

        </div>





        <!--
          - ASIDE
        -->

        <div class="aside">

          <div class="topics">

            <h2 class="h2"> Dommaines</h2>

            <a href="#" class="topic-btn">
              <div class="icon-box">
                <ion-icon name="server-outline"></ion-icon>
              </div>

              <p>Programation</p>
            </a>

            <a href="#" class="topic-btn">
              <div class="icon-box">
                <ion-icon name="accessibility-outline"></ion-icon>
              </div>

              <p>Domotique</p>
            </a>

            <a href="#" class="topic-btn">
              <div class="icon-box">
                <ion-icon name="rocket-outline"></ion-icon>
              </div>

              <p>Electronique</p>
            </a>

            <a href="#" class="topic-btn">
              <div class="icon-box">
                <ion-icon name="rocket-outline"></ion-icon>
              </div>

              <p>Robotique</p>
            </a>
          </div>

          

          <div class="contact">

            <h2 class="h2">Parlons un peu </h2>

            <div class="wrapper">

              <p>
               Voulez-vous savoir comment je peux aider votre entreprise à résoudre ses problèmes? 
               Nous pouvons discuter là-dèssus
              </p>

              <ul class="social-link">

                <li>
                  <a href="https://instagram.com/edembinks?r=nametag" class="icon-box discord">
                    <img src="./assets/images/insta.jpg" width="50px" height="50px" >
                  </a>
                </li>

                <li>
                  <a href="https://wa.me/+22968548443" class="icon-box twitter">
                  <img src="./assets/images/what.jpg" width="50px" height="50px" >  
                  </a>
                </li>

                <li>
                  <a href="https://free.facebook.com/casimiredem.madetinkpomachi.9?eav=AfaeGtM6HgHgTI8C9zUEkw_4nUR6mFS-SWMf10DyRx9KoK5cuM1UK7XEJCqcXs5Vrc&ref_component=mfreebasics_home_header&ref_page=MMessagingEntBasedReadController&refid=12&paipv=" class="icon-box facebook">
                  <img src="./assets/images/fb.jpg" width="50px" height="50px" >
                  </a>
                </li>

              </ul>

            </div>

          </div>

          <div class="newsletter">

            <h2 class="h2">Nous contacter</h2>

            <div class="wrapper">

              <p>
                Vous avez une préoccupation veuillez nous écrire 
              </p>

              <form action="#">
                <input type="text" name="name" placeholder="Votre Nom" required>
                <input type="text" name="prenom" placeholder="Votre prénom" required>
                <input type="email" name="email" placeholder="Email Address" required>

                <button type="submit" class="btn btn-primary">ENTRER</button>
              </form>

            </div>

          </div>

        </div>

      </div>

    </div>

  </main>
  <?php include 'include/footer.php'; ?>
  <!--
    - custom js link
  -->
  <script src="./assets/js/script.js"></script>

  <!--
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>